/**
 * server/routes/notifications.d.ts
 * (Empty file to satisfy TS isolatedModules if needed)
 */
export {}
